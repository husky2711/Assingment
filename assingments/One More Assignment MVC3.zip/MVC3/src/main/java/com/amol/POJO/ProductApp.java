package com.amol.POJO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class ProductApp {

	public static void main(String[] args) {
		
		Product product = new Product();
		product.setId(1);
		product.setName("Ear Phones");
		product.setPrice(989);
		product.setQty(10);
		
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment","root","amybro");
		
		PreparedStatement pst = con.prepareStatement("insert into product values(?,?,?,?) ");
		pst.setInt(1, product.getId());
		pst.setString(2, product.getName());
		pst.setInt(3, product.getPrice());
		pst.setInt(4, product.getQty());
		
		int res=pst.executeUpdate();
		System.out.println("----Before Persistance");
		System.out.println(product);
		if(res>0)
			System.out.println("Object Persisted");
		
		product=null;
		
		System.out.println("----After Persistance");
		
		Statement st = con.createStatement();
		product=new Product();
		ResultSet rs = st.executeQuery("select * from product");
		if(rs.next()) {
			product.setId(rs.getInt(1));
			product.setName(rs.getString(2));
			product.setPrice(rs.getInt(3));
			product.setQty(rs.getInt(4));
			
		}
		
		System.out.println(product);
		
		
		
		
		}catch(Exception e) {e.printStackTrace(); }
		

	}

}
