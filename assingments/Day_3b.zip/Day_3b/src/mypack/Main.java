package mypack;
import java.util.HashSet;
import java.util.Set;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class Main 
{
	public static void main(String[] args) 
	{
		Session session = HibernateUtil.getSessionFactory().openSession(); 
        Transaction transaction = null; 
        try 
        {
        	transaction = session.beginTransaction(); 
        	Book b1=new Book();
        	Author a1=new Author();
        	a1.setAddress("lko");
        	a1.setName("sarvesh");
        	Author a2=new Author();
        	a2.setAddress("alhd");
        	a2.setName("Vishwas");
        	Author a3=new Author();
        	a3.setAddress("Bombay");
        	a3.setName("Ekta");
        	Set<Author> h=new HashSet<Author>();
        	h.add(a1);
        	h.add(a2);
        	h.add(a3);
        	b1.setTitle("four hour week");
        	b1.setCost(600);
        	b1.setAuthors(h);
        	session.save(b1);
            transaction.commit(); 
            session.close();
            session=HibernateUtil.getSessionFactory().openSession();
            Book ref=(Book)session.get(Book.class,new Integer(1));
            session.close();
            System.out.println(ref.getCost());
            System.out.println(ref.getTitle());
            //System.out.println(ref.getAuthors());
            System.out.println("done");
            
        }
        catch(Exception ee)
        {
        	System.out.println("in catch\t"+ee);
        }
	}
	
}
