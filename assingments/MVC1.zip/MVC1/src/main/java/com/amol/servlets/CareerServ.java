package com.amol.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.amol.helpers.CareerExpert;

/**
 * Servlet implementation class CareerServ
 */
public class CareerServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private CareerExpert expert;
	
	@Override
	public void init() throws ServletException {
		expert=new CareerExpert();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setAttribute("carMSG", expert.getAdvice(request.getParameter("quali")));
		
		request.getRequestDispatcher("CareerDetails.jsp").forward(request, response);
			
	}

}
