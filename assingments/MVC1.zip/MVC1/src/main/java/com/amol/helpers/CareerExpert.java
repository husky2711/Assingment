package com.amol.helpers;

public class CareerExpert {

	public String getAdvice(String qualification) {
		
		if(qualification.equalsIgnoreCase("BE"))
			return "CDAC";
		else if(qualification.equalsIgnoreCase("BSC"))
			return "DBDA";
		else if(qualification.equalsIgnoreCase("MSC"))
			return "EMBADED";
		
		return "Please choose correct";
	}
}
