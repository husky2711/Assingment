package mypack;
import javax.persistence.*;
import java.util.Set;

@Entity
public class Group 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String name,technology;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn( referencedColumnName="id")
	private Set<Member> members;
	public Group() {
		
	}
	public Group(String name, String technology, Set<Member> members) {
		
		this.name = name;
		this.technology = technology;
		this.members = members;
		
	}
	/**
	 * @return the id
	 */
	
   
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the technology
	 */
	
	public String getTechnology() {
		return technology;
	}
	/**
	 * @param technology the technology to set
	 */
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	/**
	 * @return the members
	 */
	
	public Set<Member> getMembers() {
		return members;
	}
	/**
	 * @param members the members to set
	 */
	public void setMembers(Set<Member> members) {
		this.members = members;
	}
	@Override
	public String toString() {
		return "Group [id=" + id + ", name=" + name + ", technology=" + technology + ", members=" + members + "]";
	}
	
	
}
