package mypack;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Main {

	public static void main(String[] args) 
	{
		Session session = HibernateUtil.getSessionFactory().openSession(); 
        Transaction transaction = null; 
        try {
        	transaction = session.beginTransaction(); 
        	Group g1=new Group();
        	Member m1=new Member();
        	m1.setName("Sarvesh");
        	m1.setAddress("lko");
        	Member m2=new Member();
        	m2.setName("Vishwas");
        	m2.setAddress("allahabad");
        	Member m3=new Member();
        	m3.setName("Monika");
        	m3.setAddress("lko");
        	Member m4=new Member();
        	m4.setName("jhonny");
        	m4.setAddress("NYC");
        	 Set<Member> h=new HashSet<Member>();
        	 h.add(m1);
        	 h.add(m2);
        	 h.add(m3);
        	 h.add(m4);
        	 g1.setName("Blinders");
        	 g1.setTechnology("java");
        	 g1.setMembers(h);
        	 session.save(g1);
             transaction.commit();
             System.out.println("Done with group");
        }
        catch(Exception ee)
        {
        	System.out.println("in catch\t"+ee);
        	 
        }

	}

}
