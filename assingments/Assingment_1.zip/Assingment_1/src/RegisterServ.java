

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import mypack.Register;


@WebServlet("/RegisterServ")
public class RegisterServ extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Register r=new Register();
		r.setAdress(request.getParameter("Address"));
		r.setEmail(request.getParameter("email"));
		r.setLogin(request.getParameter("login"));
		r.setName(request.getParameter("name"));
		r.setPassword(request.getParameter("password"));
		
		System.out.println(r);
		Configuration conf=new Configuration().configure();
		SessionFactory factory = conf.buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx=session.beginTransaction();
		Object rs=session.save(r);
		if(rs!=null)
		{
			System.out.println("registration successfull");
		}
		else
		{
			System.out.println("registration failed");
		}
		tx.commit();
		//session.close();
	}

}
